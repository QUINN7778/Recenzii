from django.urls import path
from . import views

urlpatterns = [
    path('posters/', views.get_posters, name='get_posters'),
    path('news/', views.get_news, name='get_news'),
]

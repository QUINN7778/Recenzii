from django.http import JsonResponse
import requests
from bs4 import BeautifulSoup

BASE_URL = "https://www.ivmuz.ru"

def get_posters(request):
    url = f"{BASE_URL}/ticket_online/"
    try:
        response = requests.get(url)
        response.encoding = 'utf-8'
        soup = BeautifulSoup(response.text, 'html.parser')
        
        posters = []
        cells = soup.select(".cell.active")
        for cell in cells:
            title = cell.select_one(".name").get_text(strip=True) if cell.select_one(".name") else ""
            description = cell.select_one(".about_performance").get_text(strip=True) if cell.select_one(".about_performance") else ""
            
            day = cell.select_one(".day").get_text(strip=True) if cell.select_one(".day") else ""
            month = cell.select_one(".month").get_text(strip=True) if cell.select_one(".month") else ""
            time = cell.select_one(".time").get_text(strip=True) if cell.select_one(".time") else ""
            date = f"{day} {month}, {time}"
            
            perf_unit = cell.select_one(".performance_unit")
            image_url = ""
            if perf_unit and perf_unit.has_attr('style'):
                style = perf_unit['style']
                if "url(" in style:
                    image_url = style.split("url(")[1].split(")")[0].strip("'\"")
            
            if image_url.startswith("/"):
                image_url = BASE_URL + image_url
                
            if title:
                posters.append({
                    "title": title,
                    "description": description,
                    "date": date,
                    "imageUrl": image_url
                })
        return JsonResponse(posters, safe=False)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

def get_news(request):
    url = f"{BASE_URL}/news/"
    try:
        response = requests.get(url)
        response.encoding = 'utf-8'
        soup = BeautifulSoup(response.text, 'html.parser')
        
        news = []
        cells = soup.select(".cell")
        for cell in cells:
            text_elem = cell.select_one(".text")
            title = text_elem.get_text(strip=True) if text_elem else ""
            
            date_elem = cell.select_one(".date")
            date = date_elem.get_text(strip=True) if date_elem else ""
            
            img_elem = cell.select_one("img")
            image_url = img_elem['src'] if img_elem and img_elem.has_attr('src') else ""
            
            if image_url.startswith("/"):
                image_url = BASE_URL + image_url
                
            if title:
                news.append({
                    "title": title,
                    "description": "",
                    "date": date,
                    "imageUrl": image_url
                })
        return JsonResponse(news, safe=False)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)
